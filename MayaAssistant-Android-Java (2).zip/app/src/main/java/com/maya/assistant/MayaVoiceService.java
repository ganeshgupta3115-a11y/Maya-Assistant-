package com.maya.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.Locale;

public class MayaVoiceService extends Service {

    private static final String CHANNEL_ID = "maya_voice_channel";
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock partialWakeLock;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean isDestroyed = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Maya AI Active")
                .setContentText("Boliye 'Hello Maya' kisi bhi command ke liye")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();
        startForeground(1001, notification);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            partialWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MayaAI::VoiceWakeLock");
            partialWakeLock.acquire();
        }

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("hi", "IN"));
            }
        });

        mainHandler.post(this::initAndStartListening);
    }

    private void initAndStartListening() {
        if (isDestroyed) return;
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                mainHandler.postDelayed(() -> startListeningCycle(), 900);
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String text = matches.get(0).toLowerCase(Locale.ROOT);
                    if (text.contains("maya") || text.contains("माया")) {
                        handleWakeCommand(matches.get(0));
                        return;
                    }
                }
                mainHandler.postDelayed(() -> startListeningCycle(), 300);
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        startListeningCycle();
    }

    private void startListeningCycle() {
        if (isDestroyed || speechRecognizer == null) return;
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            speechRecognizer.startListening(intent);
        } catch (Exception ignored) {
            mainHandler.postDelayed(this::startListeningCycle, 1200);
        }
    }

    private void handleWakeCommand(String fullTranscript) {
        new Thread(() -> {
            MayaActionExecutor.CommandResult res = MayaActionExecutor.sendToMayaBrain(fullTranscript);
            mainHandler.post(() -> {
                if (res.error == null) {
                    if (tts != null && res.spokenReply != null) {
                        tts.speak(res.spokenReply, TextToSpeech.QUEUE_FLUSH, null, "maya_bg_reply");
                    }
                    MayaActionExecutor.execute(getApplicationContext(), res);
                }
                mainHandler.postDelayed(this::startListeningCycle, 2000);
            });
        }).start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Maya Voice Listener", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isDestroyed = true;
        if (partialWakeLock != null && partialWakeLock.isHeld()) {
            partialWakeLock.release();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
