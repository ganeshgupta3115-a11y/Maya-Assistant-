package com.maya.assistant;

import android.Manifest;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MayaActionExecutor {

    public static class CommandResult {
        public String action = "GENERAL_REPLY";
        public String contactName = "";
        public String messageText = "";
        public String appName = "";
        public String torchState = "";
        public String alarmTime = "";
        public String spokenReply = "";
        public String actionSummary = "";
        public String error = null;
    }

    public static CommandResult sendToMayaBrain(String transcript) {
        try {
            URL url = new URL(BuildConfig.MAYA_API_BASE_URL + "/api/maya/command");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(6000);
            conn.setDoOutput(true);

            JSONObject payload = new JSONObject();
            payload.put("transcript", transcript);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                String body = sb.toString().trim();
                if (body.startsWith("{")) {
                    JSONObject json = new JSONObject(body);
                    CommandResult result = new CommandResult();
                    result.action = json.optString("action", "GENERAL_REPLY");
                    result.contactName = json.optString("contactName", "");
                    result.messageText = json.optString("messageText", "");
                    result.appName = json.optString("appName", "");
                    result.torchState = json.optString("torchState", "");
                    result.alarmTime = json.optString("alarmTime", "");
                    result.spokenReply = json.optString("spokenReply", "Ji, ho gaya.");
                    result.actionSummary = json.optString("actionSummary", "Maya");
                    return result;
                }
            }
        } catch (Exception ignored) {
            // Fall back seamlessly to Maya's built-in Hindi/Hinglish/English local engine
        }
        return parseLocally(transcript);
    }

    private static CommandResult parseLocally(String rawTranscript) {
        CommandResult res = new CommandResult();
        String text = rawTranscript == null ? "" : rawTranscript.trim();
        text = text.replaceAll("(?i)^(hello|hey|hi|ok|okay)?\\s*maya[,\\s]*", "");
        text = text.replaceAll("^(हेलो|हे|हाय)?\\s*माया[,\\s]*", "").trim();
        String lower = text.toLowerCase(Locale.ROOT);

        if (lower.contains("lock") || text.contains("लॉक") || text.contains("स्क्रीन बंद")) {
            res.action = "LOCK_PHONE";
            res.actionSummary = "Phone Lock";
            res.spokenReply = "Phone lock kar rahi hoon.";
            return res;
        }

        if (lower.contains("camera") || text.contains("कैमरा") || lower.contains("selfie")
                || text.contains("फोटो") || text.contains("सेल्फी")) {
            res.action = "OPEN_CAMERA";
            res.actionSummary = "Open Camera";
            res.spokenReply = "Camera khol rahi hoon.";
            return res;
        }

        if (lower.contains("torch") || lower.contains("flashlight") || lower.contains("flash")
                || text.contains("टॉर्च") || text.contains("फ्लैश")) {
            boolean turnOff = lower.contains("off") || lower.contains("band") || text.contains("बंद");
            res.action = "TOGGLE_TORCH";
            res.torchState = turnOff ? "OFF" : "ON";
            res.actionSummary = turnOff ? "Torch OFF" : "Torch ON";
            res.spokenReply = turnOff ? "Torch band kar di." : "Torch jala di.";
            return res;
        }

        if (lower.contains("alarm") || text.contains("अलार्म")) {
            res.action = "SET_ALARM";
            String digits = text.replaceAll("[^0-9:]", " ").trim();
            res.alarmTime = digits.isEmpty() ? "07:00" : digits.split("\\s+")[0];
            if (!res.alarmTime.contains(":")) {
                res.alarmTime = res.alarmTime + ":00";
            }
            res.actionSummary = "Alarm " + res.alarmTime;
            res.spokenReply = "Alarm set kar rahi hoon.";
            return res;
        }

        if (lower.contains("whatsapp") || lower.contains("message") || lower.contains("msg")
                || text.contains("व्हाट्सएप") || text.contains("वॉट्सऐप")
                || text.contains("मैसेज") || text.contains("संदेश")) {
            res.action = "SEND_WHATSAPP";
            extractContactAndMessage(text, res);
            if (res.contactName.isEmpty()) {
                res.spokenReply = "Kisko message bhejna hai? Naam bhi boliye.";
            } else if (res.messageText.isEmpty()) {
                res.actionSummary = "Open WhatsApp: " + res.contactName;
                res.spokenReply = res.contactName + " ki WhatsApp chat khol rahi hoon.";
            } else {
                res.actionSummary = "WhatsApp to " + res.contactName;
                res.spokenReply = res.contactName + " ko WhatsApp bhej rahi hoon.";
            }
            return res;
        }

        if (lower.contains("call") || lower.contains("phone lagao")
                || text.contains("कॉल") || text.contains("फोन लगा") || text.contains("फोन कर")) {
            res.action = "MAKE_CALL";
            String name = text
                    .replaceAll("(?i)\\b(please|call|phone|lagao|karo|ko|to)\\b", " ")
                    .replaceAll("(कॉल|फोन|लगाओ|करो|को|की|कृपया)", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            res.contactName = name;
            res.actionSummary = "Call " + name;
            res.spokenReply = name.isEmpty() ? "Kisko call karna hai?" : name + " ko call laga rahi hoon.";
            return res;
        }

        if (lower.contains("phone open") || lower.contains("unlock") || lower.contains("screen on")
                || text.contains("फोन खोलो") || text.contains("अनलॉक") || text.contains("स्क्रीन ऑन")) {
            res.action = "WAKE_SCREEN";
            res.actionSummary = "Wake Screen";
            res.spokenReply = "Screen on kar rahi hoon. Security ke liye PIN ya fingerprint khud lagana hoga.";
            return res;
        }

        if (lower.contains("open") || lower.contains("kholo") || lower.contains("chalao")
                || text.contains("खोलो") || text.contains("खोल") || text.contains("चलाओ")) {
            res.action = "OPEN_APP";
            String app = text
                    .replaceAll("(?i)\\b(please|open|the|app|kholo|chalao|start)\\b", " ")
                    .replaceAll("(खोलो|खोल|चलाओ|ऐप|दें|दो)", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            res.appName = mapAppName(app);
            res.actionSummary = "Open " + res.appName;
            res.spokenReply = res.appName + " khol rahi hoon.";
            return res;
        }

        if (lower.contains("time") || text.contains("टाइम") || text.contains("बजे")) {
            String timeNow = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
            res.action = "GENERAL_REPLY";
            res.actionSummary = "Time: " + timeNow;
            res.spokenReply = "Abhi " + timeNow + " ho rahe hain.";
            return res;
        }

        if (lower.contains("date") || lower.contains("aaj") || text.contains("तारीख") || text.contains("आज")) {
            String dateNow = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date());
            res.action = "GENERAL_REPLY";
            res.actionSummary = dateNow;
            res.spokenReply = "Aaj " + dateNow + " hai.";
            return res;
        }

        if (lower.contains("kaise ho") || lower.contains("kaisi ho") || lower.contains("how are you")
                || text.contains("कैसे हो") || text.contains("कैसी हो")) {
            res.action = "GENERAL_REPLY";
            res.actionSummary = "Maya Chat";
            res.spokenReply = "Main bilkul badhiya hoon! Aap bataiye, aapka kaunsa kaam karun?";
            return res;
        }

        if (lower.contains("joke") || text.contains("जोक") || text.contains("चुटकुला")) {
            res.action = "GENERAL_REPLY";
            res.actionSummary = "Maya Joke";
            res.spokenReply = "Ek dost ne pucha phone garam kyun ho raha hai? Maine kaha shayad Maya aaj kuch zyada hi tez kaam kar rahi hai!";
            return res;
        }

        if (lower.contains("thank") || lower.contains("shukriya") || text.contains("शुक्रिया") || text.contains("धन्यवाद")) {
            res.action = "GENERAL_REPLY";
            res.actionSummary = "Maya Chat";
            res.spokenReply = "Aapka swagat hai! Jab bhi zaroorat ho bas Hello Maya bol dijiye.";
            return res;
        }

        res.action = "GENERAL_REPLY";
        res.actionSummary = "Maya Ready";
        res.spokenReply = "Ji haan, main sun rahi hoon! Aap mujhse baat kar sakte hain, camera khol sakte hain, ya kisi ko WhatsApp bhej sakte hain.";
        return res;
    }

    private static void extractContactAndMessage(String text, CommandResult res) {
        String[] splitMarkers = {
                "को व्हाट्सएप करो", "को वॉट्सऐप करो", "को मैसेज करो", "को संदेश भेजो",
                "ko whatsapp karo", "ko message karo", "ko msg karo", "ko message",
                "को मैसेज", "को व्हाट्सएप"
        };

        for (String marker : splitMarkers) {
            int idx = text.toLowerCase(Locale.ROOT).indexOf(marker.toLowerCase(Locale.ROOT));
            if (idx >= 0) {
                String before = text.substring(0, idx).trim();
                String after = text.substring(idx + marker.length()).trim();
                after = after.replaceAll("^(कि|की|ki)\\s+", "").trim();
                res.contactName = cleanContactWords(before);
                res.messageText = after;
                return;
            }
        }

        String cleaned = text
                .replaceAll("(?i)\\b(send|whatsapp|message|msg|to|on)\\b", " ")
                .replaceAll("(व्हाट्सएप|वॉट्सऐप|मैसेज|संदेश|भेजो|करो)", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (!cleaned.isEmpty()) {
            String[] parts = cleaned.split("\\s+", 2);
            res.contactName = cleanContactWords(parts[0]);
            res.messageText = parts.length > 1 ? parts[1].replaceAll("^(कि|की|ki|ko|को)\\s+", "").trim() : "";
        }
    }

    private static String cleanContactWords(String s) {
        return s.replaceAll("(?i)\\b(please|send|whatsapp|message|msg|to|ko)\\b", " ")
                .replaceAll("(कृपया|को|मैसेज|व्हाट्सएप|भेजो|करो)", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private static String mapAppName(String raw) {
        String l = raw.toLowerCase(Locale.ROOT);
        if (l.contains("यूट्यूब") || l.contains("youtube")) return "YouTube";
        if (l.contains("व्हाट्सएप") || l.contains("वॉट्सऐप") || l.contains("whatsapp")) return "WhatsApp";
        if (l.contains("इंस्टाग्राम") || l.contains("instagram")) return "Instagram";
        if (l.contains("क्रोम") || l.contains("chrome")) return "Chrome";
        if (l.contains("मैप") || l.contains("maps")) return "Maps";
        if (l.contains("सेटिंग") || l.contains("settings")) return "Settings";
        if (l.contains("कैलकुलेटर") || l.contains("calculator")) return "Calculator";
        if (l.contains("गैलरी") || l.contains("gallery") || l.contains("photos")) return "Photos";
        return transliterateHindiToLatin(raw);
    }

    public static void execute(Context context, CommandResult cmd) {
        switch (cmd.action) {
            case "LOCK_PHONE":
                lockPhone(context);
                break;
            case "WAKE_SCREEN":
                wakeScreen(context);
                break;
            case "OPEN_CAMERA":
                openCamera(context);
                break;
            case "SEND_WHATSAPP":
                sendWhatsApp(context, cmd.contactName, cmd.messageText);
                break;
            case "SEND_SMS":
                sendSms(context, cmd.contactName, cmd.messageText);
                break;
            case "MAKE_CALL":
                makeCall(context, cmd.contactName);
                break;
            case "TOGGLE_TORCH":
                toggleTorch(context, "ON".equalsIgnoreCase(cmd.torchState));
                break;
            case "OPEN_APP":
                openApp(context, cmd.appName);
                break;
            case "SET_ALARM":
                setAlarm(context, cmd.alarmTime);
                break;
            default:
                break;
        }
    }

    @SuppressWarnings("deprecation")
    private static void wakeScreen(Context context) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                PowerManager.WakeLock wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "MayaAI::ScreenWake");
                wl.acquire(4000L);
            }
        } catch (Exception ignored) {}
    }

    private static void lockPhone(Context context) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(context, MayaDeviceAdminReceiver.class);
        if (dpm != null && dpm.isAdminActive(admin)) {
            dpm.lockNow();
        } else {
            Toast.makeText(context, "Pehle 2. Enable Phone Lock (Device Admin) ON karein.", Toast.LENGTH_LONG).show();
        }
    }

    private static void openCamera(Context context) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void sendWhatsApp(Context context, String contactName, String message) {
        String phone = findPhoneNumber(context, contactName);
        if (phone == null || phone.isEmpty()) {
            Toast.makeText(context, contactName + " ka number Contacts mein nahi mila.", Toast.LENGTH_LONG).show();
            return;
        }
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() == 10) {
            digits = "91" + digits;
        }
        String cleanMsg = message == null ? "" : message.trim();
        if (!cleanMsg.isEmpty()) {
            MayaAccessibilityService.armAutoSend();
        }
        try {
            String url = "https://api.whatsapp.com/send?phone=" + digits +
                    (cleanMsg.isEmpty() ? "" : "&text=" + URLEncoder.encode(cleanMsg, "UTF-8"));
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "WhatsApp open nahi ho paya: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static void sendSms(Context context, String contactName, String message) {
        String phone = findPhoneNumber(context, contactName);
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + (phone == null ? "" : phone)));
        intent.putExtra("sms_body", message);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void makeCall(Context context, String contactName) {
        String phone = findPhoneNumber(context, contactName);
        if (phone == null || phone.isEmpty()) {
            Toast.makeText(context, contactName + " ka number nahi mila.", Toast.LENGTH_LONG).show();
            return;
        }
        boolean hasCallPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED;
        Intent intent = new Intent(hasCallPerm ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                Uri.parse("tel:" + phone));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void toggleTorch(Context context, boolean enable) {
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cm != null && cm.getCameraIdList().length > 0) {
                cm.setTorchMode(cm.getCameraIdList()[0], enable);
            }
        } catch (Exception e) {
            Toast.makeText(context, "Torch error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static void openApp(Context context, String appName) {
        if (appName == null || appName.isEmpty()) return;
        String target = appName.toLowerCase(Locale.ROOT);
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo app : apps) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase(Locale.ROOT);
            if (label.contains(target)) {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return;
                }
            }
        }
        Toast.makeText(context, appName + " app phone mein nahi mila.", Toast.LENGTH_SHORT).show();
    }

    private static void setAlarm(Context context, String alarmTime) {
        int hour = 7;
        int minute = 0;
        if (alarmTime != null && alarmTime.contains(":")) {
            String[] parts = alarmTime.split(":");
            try {
                hour = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
                minute = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
            } catch (Exception ignored) {}
        }
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        intent.putExtra(AlarmClock.EXTRA_HOUR, hour);
        intent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
        intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Maya Alarm");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static String findPhoneNumber(Context context, String name) {
        if (name == null || name.trim().isEmpty()) return null;
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        String rawQuery = name.trim().toLowerCase(Locale.ROOT);
        String phoneticQuery = simplifyPhonetic(transliterateHindiToLatin(rawQuery));

        try (Cursor cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                },
                null, null, null)) {
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String displayName = cursor.getString(0);
                    String number = cursor.getString(1);
                    if (displayName == null || number == null) continue;
                    String lowerDisplay = displayName.toLowerCase(Locale.ROOT);
                    if (lowerDisplay.contains(rawQuery)) {
                        return number;
                    }
                    String phoneticDisplay = simplifyPhonetic(transliterateHindiToLatin(lowerDisplay));
                    if (!phoneticQuery.isEmpty() && phoneticDisplay.contains(phoneticQuery)) {
                        return number;
                    }
                }
            }
        }
        return null;
    }

    private static String simplifyPhonetic(String s) {
        return s.toLowerCase(Locale.ROOT)
                .replace("aa", "a")
                .replace("ee", "i")
                .replace("oo", "u")
                .replace("sh", "s")
                .replace("ph", "f")
                .replace("bh", "b")
                .replace("kh", "k")
                .replace("gh", "g")
                .replace("th", "t")
                .replace("dh", "d")
                .replace("v", "w")
                .replaceAll("[^a-z0-9]", "");
    }

    private static String transliterateHindiToLatin(String input) {
        if (input == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            switch (c) {
                case 'अ': out.append("a"); break;
                case 'आ': out.append("aa"); break;
                case 'इ': case 'ई': out.append("i"); break;
                case 'उ': case 'ऊ': out.append("u"); break;
                case 'ए': case 'ऐ': out.append("e"); break;
                case 'ओ': case 'औ': out.append("o"); break;
                case 'ा': out.append("a"); break;
                case 'ि': case 'ी': out.append("i"); break;
                case 'ु': case 'ू': out.append("u"); break;
                case 'े': case 'ै': out.append("e"); break;
                case 'ो': case 'ौ': out.append("o"); break;
                case 'ं': case 'ँ': out.append("n"); break;
                case 'क': out.append("k"); break;
                case 'ख': out.append("kh"); break;
                case 'ग': out.append("g"); break;
                case 'घ': out.append("gh"); break;
                case 'च': out.append("ch"); break;
                case 'छ': out.append("chh"); break;
                case 'ज': out.append("j"); break;
                case 'झ': out.append("jh"); break;
                case 'ट': case 'त': out.append("t"); break;
                case 'ठ': case 'थ': out.append("th"); break;
                case 'ड': case 'द': out.append("d"); break;
                case 'ढ': case 'ध': out.append("dh"); break;
                case 'ण': case 'न': out.append("n"); break;
                case 'प': out.append("p"); break;
                case 'फ': out.append("ph"); break;
                case 'ब': out.append("b"); break;
                case 'भ': out.append("bh"); break;
                case 'म': out.append("m"); break;
                case 'य': out.append("y"); break;
                case 'र': out.append("r"); break;
                case 'ल': out.append("l"); break;
                case 'व': out.append("v"); break;
                case 'श': case 'ष': out.append("sh"); break;
                case 'स': out.append("s"); break;
                case 'ह': out.append("h"); break;
                case '्': break;
                default: out.append(c); break;
            }
        }
        return out.toString();
    }
}
