package com.maya.assistant;

import android.app.admin.DeviceAdminReceiver;

public class MayaDeviceAdminReceiver extends DeviceAdminReceiver {
}
