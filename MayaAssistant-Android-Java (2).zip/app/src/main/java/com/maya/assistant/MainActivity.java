package com.maya.assistant;

import android.Manifest;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;
    private TextView tvLastReply;
    private EditText etCommand;
    private TextToSpeech tts;
    private boolean wakeServiceRunning = false;

    private final ActivityResultLauncher<Intent> speechLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    ArrayList<String> matches = result.getData()
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (matches != null && !matches.isEmpty()) {
                        String spoken = matches.get(0);
                        tvStatus.setText("You said: " + spoken);
                        processCommand(spoken);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        tvLastReply = findViewById(R.id.tvLastReply);
        etCommand = findViewById(R.id.etCommand);
        Button btnSpeakNow = findViewById(R.id.btnSpeakNow);
        Button btnSendText = findViewById(R.id.btnSendText);
        Button btnToggleWake = findViewById(R.id.btnToggleWake);
        Button btnPermRuntime = findViewById(R.id.btnPermRuntime);
        Button btnPermAdmin = findViewById(R.id.btnPermAdmin);
        Button btnPermAccessibility = findViewById(R.id.btnPermAccessibility);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("hi", "IN"));
            }
        });

        btnSpeakNow.setOnClickListener(v -> startOneShotSpeech());

        btnSendText.setOnClickListener(v -> {
            String typed = etCommand.getText().toString().trim();
            if (!typed.isEmpty()) {
                tvStatus.setText("Command: " + typed);
                etCommand.setText("");
                processCommand(typed);
            }
        });

        btnToggleWake.setOnClickListener(v -> {
            if (!hasMicPermission()) {
                requestRuntimePermissions();
                return;
            }
            Intent serviceIntent = new Intent(this, MayaVoiceService.class);
            if (!wakeServiceRunning) {
                ContextCompat.startForegroundService(this, serviceIntent);
                wakeServiceRunning = true;
                btnToggleWake.setText("Stop Hello Maya Listener");
                tvStatus.setText("Hello Maya listener active hai.");
            } else {
                stopService(serviceIntent);
                wakeServiceRunning = false;
                btnToggleWake.setText("Start Hello Maya Background Listener");
                tvStatus.setText("Background listener band hai.");
            }
        });

        btnPermRuntime.setOnClickListener(v -> requestRuntimePermissions());

        btnPermAdmin.setOnClickListener(v -> {
            ComponentName adminComp = new ComponentName(this, MayaDeviceAdminReceiver.class);
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Maya uses Device Admin only to lock your screen when you say 'Lock phone'.");
            startActivity(intent);
        });

        btnPermAccessibility.setOnClickListener(v -> {
            Toast.makeText(this, "Installed apps mein 'Maya WhatsApp Auto-Sender' ON karein", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
    }

    private boolean hasMicPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRuntimePermissions() {
        ArrayList<String> perms = new ArrayList<>();
        perms.add(Manifest.permission.RECORD_AUDIO);
        perms.add(Manifest.permission.READ_CONTACTS);
        perms.add(Manifest.permission.CALL_PHONE);
        perms.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        ActivityCompat.requestPermissions(this, perms.toArray(new String[0]), 101);
    }

    private void startOneShotSpeech() {
        if (!hasMicPermission()) {
            requestRuntimePermissions();
            return;
        }
        if (wakeServiceRunning) {
            stopService(new Intent(this, MayaVoiceService.class));
            wakeServiceRunning = false;
            Button btnToggleWake = findViewById(R.id.btnToggleWake);
            if (btnToggleWake != null) {
                btnToggleWake.setText("Start Hello Maya Background Listener");
            }
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye Maya ko kya karna hai...");
        speechLauncher.launch(intent);
    }

    private void processCommand(String transcript) {
        new Thread(() -> {
            MayaActionExecutor.CommandResult res = MayaActionExecutor.sendToMayaBrain(transcript);
            runOnUiThread(() -> {
                if (res.error != null) {
                    tvLastReply.setText("Error: " + res.error);
                    return;
                }
                tvLastReply.setText("Action: " + res.actionSummary + "\nMaya: " + res.spokenReply);
                if (tts != null && res.spokenReply != null) {
                    tts.speak(res.spokenReply, TextToSpeech.QUEUE_FLUSH, null, "maya_reply");
                }
                MayaActionExecutor.execute(MainActivity.this, res);
            });
        }).start();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
