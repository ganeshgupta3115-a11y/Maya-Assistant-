# Maya AI Assistant (Android Java)

## Phone ke liye APK kaise banayein (GitHub se - Bina Laptop ke)

1. **GitHub.com** par login karein.
2. Nayi Repository banayein (jaise `maya-assistant`).
3. Is ZIP ki saari files aur folders (including `.github` folder) upload karke **Commit changes** dabayein.
4. Repository ke **Actions** tab mein jayein -> `Build Maya AI Android APK` workflow chal raha hoga.
5. 2-3 minute mein green tick aane par neeche **Artifacts -> Maya-Assistant-APK** par click karke download karein.
6. Phone mein `.apk` install karein aur 3 permissions ON karein:
   - Mic, Contacts, Call
   - Device Admin (Phone Lock ke liye)
   - Accessibility -> Maya WhatsApp Auto-Sender (WhatsApp auto-send ke liye)
