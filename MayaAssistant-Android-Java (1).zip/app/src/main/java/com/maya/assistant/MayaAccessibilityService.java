package com.maya.assistant;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class MayaAccessibilityService extends AccessibilityService {

    private static volatile long armedUntilMs = 0L;

    public static void armAutoSend() {
        armedUntilMs = System.currentTimeMillis() + 12000L;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (System.currentTimeMillis() > armedUntilMs) {
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        List<AccessibilityNodeInfo> sendButtons = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send");
        if (sendButtons == null || sendButtons.isEmpty()) {
            sendButtons = root.findAccessibilityNodeInfosByViewId("com.whatsapp.w4b:id/send");
        }
        if (sendButtons != null && !sendButtons.isEmpty()) {
            for (AccessibilityNodeInfo btn : sendButtons) {
                if (btn.isClickable()) {
                    btn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    armedUntilMs = 0L;
                    break;
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
    }
}
