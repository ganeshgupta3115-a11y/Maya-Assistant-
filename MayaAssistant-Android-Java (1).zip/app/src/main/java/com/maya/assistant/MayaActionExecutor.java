package com.maya.assistant;

import android.Manifest;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

public class MayaActionExecutor {

    public static class CommandResult {
        public String action = "GENERAL_REPLY";
        public String contactName = "";
        public String messageText = "";
        public String appName = "";
        public String torchState = "";
        public String alarmTime = "";
        public String spokenReply = "";
        public String actionSummary = "";
        public String error = null;
    }

    public static CommandResult sendToMayaBrain(String transcript) {
        CommandResult result = new CommandResult();
        try {
            URL url = new URL(BuildConfig.MAYA_API_BASE_URL + "/api/maya/command");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            conn.setDoOutput(true);

            JSONObject payload = new JSONObject();
            payload.put("transcript", transcript);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            JSONObject json = new JSONObject(sb.toString());
            if (code >= 400) {
                result.error = json.optString("error", "Server error " + code);
                return result;
            }

            result.action = json.optString("action", "GENERAL_REPLY");
            result.contactName = json.optString("contactName", "");
            result.messageText = json.optString("messageText", "");
            result.appName = json.optString("appName", "");
            result.torchState = json.optString("torchState", "");
            result.alarmTime = json.optString("alarmTime", "");
            result.spokenReply = json.optString("spokenReply", "Ji, ho gaya.");
            result.actionSummary = json.optString("actionSummary", "Maya");
        } catch (Exception e) {
            result.error = e.getMessage();
        }
        return result;
    }

    public static void execute(Context context, CommandResult cmd) {
        switch (cmd.action) {
            case "LOCK_PHONE":
                lockPhone(context);
                break;
            case "OPEN_CAMERA":
                openCamera(context);
                break;
            case "SEND_WHATSAPP":
                sendWhatsApp(context, cmd.contactName, cmd.messageText);
                break;
            case "SEND_SMS":
                sendSms(context, cmd.contactName, cmd.messageText);
                break;
            case "MAKE_CALL":
                makeCall(context, cmd.contactName);
                break;
            case "TOGGLE_TORCH":
                toggleTorch(context, "ON".equalsIgnoreCase(cmd.torchState));
                break;
            case "OPEN_APP":
                openApp(context, cmd.appName);
                break;
            case "SET_ALARM":
                setAlarm(context, cmd.alarmTime);
                break;
            default:
                break;
        }
    }

    private static void lockPhone(Context context) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(context, MayaDeviceAdminReceiver.class);
        if (dpm != null && dpm.isAdminActive(admin)) {
            dpm.lockNow();
        } else {
            Toast.makeText(context, "Pehle Device Admin permission ON karein.", Toast.LENGTH_LONG).show();
        }
    }

    private static void openCamera(Context context) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void sendWhatsApp(Context context, String contactName, String message) {
        String phone = findPhoneNumber(context, contactName);
        if (phone == null || phone.isEmpty()) {
            Toast.makeText(context, contactName + " ka number Contacts mein nahi mila.", Toast.LENGTH_LONG).show();
            return;
        }
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() == 10) {
            digits = "91" + digits;
        }
        MayaAccessibilityService.armAutoSend();
        try {
            String url = "https://api.whatsapp.com/send?phone=" + digits + "&text=" +
                    URLEncoder.encode(message, "UTF-8");
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "WhatsApp open nahi ho paya: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static void sendSms(Context context, String contactName, String message) {
        String phone = findPhoneNumber(context, contactName);
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + (phone == null ? "" : phone)));
        intent.putExtra("sms_body", message);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void makeCall(Context context, String contactName) {
        String phone = findPhoneNumber(context, contactName);
        if (phone == null || phone.isEmpty()) {
            Toast.makeText(context, contactName + " ka number nahi mila.", Toast.LENGTH_LONG).show();
            return;
        }
        boolean hasCallPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED;
        Intent intent = new Intent(hasCallPerm ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                Uri.parse("tel:" + phone));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void toggleTorch(Context context, boolean enable) {
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cm != null && cm.getCameraIdList().length > 0) {
                cm.setTorchMode(cm.getCameraIdList()[0], enable);
            }
        } catch (Exception e) {
            Toast.makeText(context, "Torch error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static void openApp(Context context, String appName) {
        if (appName == null || appName.isEmpty()) return;
        String target = appName.toLowerCase(Locale.ROOT);
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo app : apps) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase(Locale.ROOT);
            if (label.contains(target)) {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return;
                }
            }
        }
        Toast.makeText(context, appName + " app phone mein nahi mila.", Toast.LENGTH_SHORT).show();
    }

    private static void setAlarm(Context context, String alarmTime) {
        int hour = 7;
        int minute = 0;
        if (alarmTime != null && alarmTime.contains(":")) {
            String[] parts = alarmTime.split(":");
            try {
                hour = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
                minute = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
            } catch (Exception ignored) {}
        }
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        intent.putExtra(AlarmClock.EXTRA_HOUR, hour);
        intent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
        intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Maya Alarm");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static String findPhoneNumber(Context context, String name) {
        if (name == null || name.trim().isEmpty()) return null;
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        String query = name.trim().toLowerCase(Locale.ROOT);
        try (Cursor cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                },
                null, null, null)) {
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String displayName = cursor.getString(0);
                    String number = cursor.getString(1);
                    if (displayName != null && displayName.toLowerCase(Locale.ROOT).contains(query)) {
                        return number;
                    }
                }
            }
        }
        return null;
    }
}
